---
name: youtube-transcript-summarizer
description: Summarize YouTube video transcripts into structured, easily readable notes with key points, Q&A format for interviews, action items, conclusions, and key quotes. Use when the user asks to summarize a YouTube video transcript, process transcript text into notes, or extract structured summaries from YouTube transcripts.
---
# YouTube Transcript Summarizer

Transform raw YouTube video transcripts into structured, concise, and highly readable summary notes for quick review and action tracking.

## When to Use

Use this skill when the user asks to:
- Summarize a YouTube video transcript
- Convert transcript text into structured notes or meeting-like minutes
- Extract key takeaways, Q&A pairs, action items, or key quotes from a transcript

## Core Rules

1. **Tone & Style**: Maintain a professional, structured, and concise tone. Eliminate filler words and verbal clutter.
2. **Formatting**: Use bold headings, numbered lists for main topics (1, 2, 3...), and bullet points (-) for sub-points.
3. **Factual Accuracy**: Rely strictly on the provided transcript. Do NOT infer, speculate, or invent facts.
4. **Preserve Key Data**: Retain specific numbers, proper nouns, technical terms, and English original words/terms.
5. **Interview Content**: Format interview dialogs as "Q (Question) → A (Key Answer Points)" pairs.
6. **Speaker Attribution**: Include speaker names in parentheses when indicated in the transcript (e.g., "(主持人)", "(受訪者)").
7. **Special Sections**: Separately extract and list:
   - Action Items / Suggested Practice Tasks
   - Conclusions
   - Key Quotes (if any memorable or powerful statements exist)

## Processing Workflow

1. **Analyze Transcript**: Read the transcript to identify the overall context, date (if mentioned), participant list, and major topic divisions.
2. **Segment into Main Topics**: Break the transcript into chronological or thematic sections and assign numbered topic titles (e.g., 1. 項目一：[主題名稱]).
3. **Extract Sub-points**: Under each main topic, list key arguments, data points, case studies, or highlights using bullet points.
4. **Identify Interview Pairs**: If the content is an interview, format each question and answer concisely.
5. **Extract Action Items**: Collate concrete tasks or learning assignments with owner, timeline (if mentioned), and specific actions.
6. **Extract Conclusion & Quotes**: Summarize the final takeaway/conclusion and pull out notable quotes.

## Output Format Template

```text
日期： [填寫日期，若無提及寫「未提及」]
參與者： [參與者名單，若無提及寫「未提及」]

一、影片摘要
1. 項目一：[主題名稱]
   - 要點 1 (講者名)
   - 要點 2
   - 要點 3

2. 項目二：[主題名稱]
   - 要點 1
   - 要點 2

[問答區段，若為訪談類內容]
- Q：[提問內容]
  - A：[回答要點 1]
  - A：[回答要點 2]

二、行動建議、項目（Action Items）
- [負責人] / [時間/期限] / [具體行動內容] (如知識型內容可調整為「建議實作 / 學習任務」)

三、結論
[影片的總結或收尾核心觀點]

四、關鍵金句 (若有具代表性或有力的表述)
- 「[金句內容]」— [講者]
```

## Gotchas

- Do not hallucinate dates or participants if not present in the transcript; mark them clearly as "未提及".
- Keep sub-points concise and informative rather than re-pasting long verbatim paragraphs.
