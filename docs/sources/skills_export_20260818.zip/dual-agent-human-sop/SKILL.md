---
name: dual-agent-human-sop
description: 雙 Agent 協作 Human 操作 SOP｜Hermes × OpenClaw × Obsidian，建立任務卡、審核報告與沉澱流程。
---
# 定位
本機雙 Agent（Hermes × OpenClaw × Obsidian）個人操作 SOP：建立任務卡、要求 Hermes 規劃、人工檢查 Plan、交付 OpenClaw 執行、審核報告並沉澱 SOP/Skill。

# 核心流程
1. 建立任務卡與風險分級（低/中/高）。
2. 請 Hermes 產出 Plan，人工檢查讀寫與權限。
3. 交給 OpenClaw 執行並產出 Execution Report。
4. Human Review 驗收與沉澱 SOP / Skill Candidate。
