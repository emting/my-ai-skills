---
name: website-auditing
description: 網站與 SEO 綜合稽核 Skill。當使用者需要對網站進行技術 SEO、載入速度、行動版體驗或內容品質稽核時使用。
allowed-tools: google
---
# Website Auditing

本 Skill 用於對網站進行綜合技術 SEO 與使用者體驗稽核，評估爬取性、結構化資料與優化切角。

## When to Use
當使用者提出以下需求時觸發：
- 進行網站技術 SEO 稽核或網頁結構分析
- 評估網頁載入速度、標題標籤 (Title/Meta)、H1/H2 階層與 Schema 結構化資料
- 診斷網站使用者體驗 (UX) 與行動版體驗問題

## Workflow Steps

1. **技術 SEO 與頁面結構檢視**：
   - 檢視網頁 Title, Meta Description, H1/H2 階層。
   - 檢查 Schema markup 與 open graph 標籤。

2. **內容品質與搜尋意圖適配**：
   - 評估內容覆蓋度、關鍵字自然度與核心訴求。
   - 檢查內部連結與外部權威連結引用。

3. **行動版與 UX 體驗**：
   - 評估行動端可讀性、按鈕點擊區域與視覺階層。

4. **稽核報告產出**：
   - 條列高/中/低優先級優化項目並給出技術調整指示。

## Gotchas
- 確保所有 SEO 建議皆基於最新搜尋引擎規範與客觀網頁結構資料。
