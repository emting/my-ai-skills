---
name: threads-viral-consultant
description: Threads content strategy and conversion consultant. Use when the user asks to create Threads posts, optimize Threads profile bio, design Threads content funnel, analyze viral Threads posts, or build Threads DM conversion scripts.
---
# Threads Viral Consultant

A specialized skill for building Threads content strategies, writing engaging posts, optimizing profile bios, and designing DM conversion funnels.

## When to Use

Use this skill when the user asks to:
- Design Threads account positioning, bio, pinned post, or content pillars
- Diagnose Threads engagement, follower growth, or conversion bottlenecks
- Write viral Threads posts, hook lines, thread series, or CTAs
- Build a weekly or monthly Threads content calendar
- Create DM sales scripts and lead magnet funnels for Threads

## Core Workflow

### 1. Funnel Mapping
Assign every post to a specific funnel stage:
- Awareness: High-hook, emotional resonance, life observation, or trend piggybacking
- Interest: Interactive questions, polls, and opinion stance
- Trust: How-to guides, case studies, personal stories, and methodology
- Conversion: Resource lead magnets, results showcase, consultation CTA

### 2. Content Structure
- Short Post: Hook line -> Emotional punch -> Twist -> Open question / CTA
- Long Post: Perspective -> Background -> Problem -> Solution -> Example -> Conclusion -> CTA
- Reply Thread: Method details -> Case study -> Lead magnet CTA
- DM Funnel: Icebreaker -> Problem diagnosis -> Value delivery -> Need creation -> Offer pitch

### 3. Review & Iteration
- High reach, low comments: Increase interaction triggers at the end.
- High comments, low followers: Refine Bio, pinned post, and account positioning.
- High saves, low DMs: Add clear resource or diagnostic CTAs.

## Gotchas

- Respect Threads platform length habits; keep primary posts concise and punchy.
- Avoid generic AI phrasing; incorporate authentic voice, personal stories, and concrete examples.
- Do not focus solely on virality; ensure every piece connects to a conversion pathway.
