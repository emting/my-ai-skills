---
name: ui-minimalist-animation-enhancer
description: Refine web/app UI for minimalism, improve information hierarchy, and add fluid entrance and exit animations. Use when the user asks to improve UI, add entrance/exit animations, simplify layout, or make interface aesthetic and clean.
---
# UI Minimalist Animation Enhancer

UI 介面極簡化重構、資訊層級優化與流暢進退場動畫建立。

## When to Use
- 使用者要求改善 App / Web UI 介面視覺與資訊架構。
- 使用者需要為元件加入進場／退場動畫。

## Steps
1. **資訊架構視覺稽核（UI & IA Audit）**：
   - 檢視元件層級、視覺雜訊（Noise）與對比度。
   - 刪除冗餘裝飾元素，落實極簡主義（Minimalist Design）。
2. **動畫系統建立（Animation Design）**：
   - 選擇適合的動畫庫（如 Framer Motion, CSS Keyframes, Tailwind Animate）。
   - 為卡片、彈窗、列表項目加入自然流暢的進場（Ease-in-out, 150-300ms）與退場動畫。
3. **資訊層級優化（Information Hierarchy Refinement）**：
   - 調整字體大小、字重與留白（Padding/Margin），讓使用者一眼能判讀核心資訊。
4. **預覽與驗收（Verification）**：
   - 檢查動畫是否具備可關閉選項（`prefers-reduced-motion` 友善支援）。
   - 提供修改前後的介面範例說明。

## Gotchas
- 動畫時間嚴格控制在 150ms - 300ms 之間，過長動畫會損害使用者體驗。
- 保留資訊層級優先於純粹視覺效果。
