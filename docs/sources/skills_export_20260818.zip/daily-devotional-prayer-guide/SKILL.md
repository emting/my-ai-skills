---
name: daily-devotional-prayer-guide
description: Guide users through a structured 4-phase daily spiritual devotional and prayer workflow (preparation, SOAP meditation, deep reflection questions, and responsive prayer). Use when the user asks for daily devotional guidance, Bible verse meditation, SOAP reflection, or structured prayer prompts.
---
# Daily Devotional Prayer Guide (每日靈修禱告指南)

Guides believers through a structured 4-phase daily devotional and prayer workflow to meditate on scripture, apply biblical truth, and pray with spiritual insight.

## When to Use

Use this skill when the user asks to:
- Conduct a daily devotional or quiet time (QT) session
- Meditate on a specific Bible verse or passage using the SOAP framework
- Receive deep reflection questions and personal application prompts for scripture
- Formulate responsive prayers based on biblical passages

## 4-Phase Devotional Workflow

### Phase 1: Scripture & Spiritual Preparation (第一階段：經文準備與屬靈預備)
- Establish a quiet space (15-30 minutes).
- Spiritual preparation prayer: "主啊，求你打開我的心眼，讓我在你的話語中遇見你。"
- Strategy: Topic-based, sequential, or liturgical devotional.

### Phase 2: SOAP Meditation Framework (第二階段：經文默想與靈修反思)
1. **Scripture (經文觀察)**: Read 2-3 times, note key terms, characters, actions, and emotions.
2. **Observation (深度觀察)**: Analyze historical/cultural context, author's purpose, and God's attributes/actions.
3. **Application (個人應用)**: Identify what God is saying today, how it challenges attitudes, and where to obey.
4. **Prayer (回應禱告)**: Give thanks for truths, confess weaknesses/sins, and pray for strength to practice.

### Phase 3: Layered Reflection Questions (第三階段：深度默想引導問題)

#### Observation Level (觀察層次)
1. 最吸引注意的詞語或片段？為什麼？
2. 神展現了什麼屬性或特質？

#### Understanding Level (理解層次)
3. 核心訊息如何連結整體救恩主題？
4. 如何用自己的話重新詮釋經文含意？

#### Application Level (應用層次)
5. 神今天特別要我關注生命中的哪個層面？
6. 經文如何挑戰目前的生活方式或價值觀？
7. 我需要向神認罪悔改的具體事項？
8. 活出真理的具體行動？

#### Prayer Level (禱告層次)
9. 最需要為誰或什麼事禱告？
10. 如何將今天的領受化為對神的讚美與感謝？

### Phase 4: Responsive Prayer Formulation (第四階段：回應禱告與實踐)
Draft a heart-felt, structured prayer including praise, confession, petition for strength, and intercession.

## Gotchas

- Avoid dry dogmatic lectures; maintain an encouraging, empathetic, and spiritually insightful tone.
- Do not make up scripture passages; use accurate biblical verses or cite specific passages provided by the user.
