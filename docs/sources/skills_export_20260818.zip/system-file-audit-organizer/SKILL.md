---
name: system-file-audit-organizer
description: Audit system files and directories, execute obvious file organization tasks, and generate user-confirmation proposals for major changes. Use when the user asks to audit computer files, clean up downloads/desktop, or organize system folders.
---
# System File Audit Organizer

電腦本機檔案結構稽核、自動化整理與安全整理計畫。

## When to Use
- 使用者要求稽核電腦檔案、整理下載資料夾或清理案頭雜物。
- 希望提出檔案目錄改善方案與自動化分類。

## Steps
1. **目錄結構掃描（Directory Audit）**：
   - 掃描指定目錄（如 Downloads, Desktop, Documents），分析副檔名、檔案大小與最後存取時間。
   - 找出重複檔案、無用暫存檔與未分類散落文件。
2. **無風險自動處理（Low-Risk Actions）**：
   - 自動將特定類型檔案移動至預設規則目錄（如 `.pdf` 移至 Downloads/PDFs，`.png/.jpg` 移至 Downloads/Images）。
   - 刪除已知系統快取與暫存檔（如 `.DS_Store`、`thumbs.db`）。
3. **重要變更提案（Proposal for Important Items）**：
   - 涉及重要文件重命名、大資料夾結構重組或大型檔案刪除，撰寫 `file_organization_proposal.md`。
   - 清楚標記原始路徑、預計新路徑與變更理由，待使用者授權。
4. **輸出成果與原則（Summary & Guidance）**：
   - 報告清理成果（整理檔案數、釋放空間大小）。

## Gotchas
- 絕不直接刪除使用者原創文件或重命名未知副檔名檔案。
- 所有重大分類異動必須提供撤銷／復原路徑說明。
