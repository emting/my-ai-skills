---
name: website-landing-page-builder
description: 網站／落地頁建置 Skill，用 Agent 直接產出可上線的互動式單頁（敘事、版面、前後對照、成本試算、CTA）。
---
# 定位
一頁式說明/課程招生/專案展示落地頁建置。擬定敘事段落（痛點→對照→機制→成本效益→社會證明→CTA），產出單檔 HTML/CSS/JS 與 SEO/GEO 要素。

# 執行步驟
1. 定敘事段落與唯一 CTA。
2. 決定互動形式（時間軸、切換對照、展開卡、試算器）。
3. 產出單檔 HTML/CSS/JS 原型（行動版優先）。
4. 補充 SEO/GEO 結構化資料與可爬取文字。
5. 人工驗收與部署。
