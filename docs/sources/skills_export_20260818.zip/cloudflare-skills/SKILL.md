---
name: cloudflare-skills
description: Cloudflare 微服務、Workers/Pages 部署與 DNS 設定診斷 Skill。當使用者需要管理、部署或排錯 Cloudflare 服務與網域設定時使用。
---
# Cloudflare Skills

本 Skill 用於管理、部署與排錯 Cloudflare Workers, Pages, DNS 記錄與邊緣安全性設定。

## When to Use
當使用者提出以下需求時觸發：
- 部署、維護或調視 Cloudflare Workers 與 Cloudflare Pages 專案
- 診斷 DNS 解析、SSL/TLS 憑證、Cache 策略與 CDN 設定
- 管理 WAF 安全規則、Headers 標頭配置與微服務整合

## Workflow Steps

1. **環境與服務狀態盤點**：
   - 確認目標項目：Workers, Pages, DNS, SSL/TLS, WAF/Rules。
   - 檢視路由設定與域名解析。

2. **部署與配置流程**：
   - 檢視 `wrangler.toml` 設定檔或 GitHub CI/CD 整合。
   - 檢查環境變數、KV / D1 / R2 bindings 設定。

3. **診斷與排錯**：
   - 檢查 HTTP 狀態碼、CORS 標頭與邊緣快取行為。

## Gotchas
- 確保 API token 權限最小化，不隨意曝光敏感密鑰。
