---
name: agent-skills-actions-auditor
description: Audit agent skills and actions, identify optimization opportunities, fix syntax or parameter issues, and refine prompt instructions. Use when the user asks to audit Codex/agent skills, optimize agent actions, or refine skill instructions.
---
# Agent Skills & Actions Auditor

Agent 技能（Skills）與動作（Actions）稽核、效能優化與修復流程。

## When to Use
- 使用者要求稽核 Codex 或 Agent 正在使用的 Skills 與 Actions。
- 需要清理冗餘提示詞、修正參數範疇或優化觸發（Trigger）精準度。

## Steps
1. **技能與動作掃描（Skill Inventory Audit）**：
   - 讀取目前工作區與系統登錄的 SKILL.md 檔案及 API 聲明。
   - 檢查 Frontmatter 的 `name`、`description` 與 `allowed-tools` 語法是否符合規範。
2. **冗餘與死角識別（Redundancy & Conflict Check）**：
   - 找出描述模糊導致頻繁誤觸發（Over-triggering）或不觸發（Under-triggering）的技能。
   - 刪除 SKILL.md 中的重複套話、不必要的 AI 罐頭範例與過時引述。
3. **精實優化（Pruning & Refinement）**：
   - 依照精實原則（Ruthless Pruning），將單一技能長度壓縮至 500 行內。
   - 強化觸發關鍵字（Context & User Phrases）精準度。
4. **修復與驗證（Save & Validate）**：
   - 呼叫更新/儲存工具更新修復後的 Skills，並提供優化摘要與觸發測試建議。

## Gotchas
- 不可隨意更換既有技能名稱（Kebab-case Name），除非使用者明確要求重命名。
- 始終維持指令精簡（Concise is Key），過度詳細的指令會排擠 Context Window。
