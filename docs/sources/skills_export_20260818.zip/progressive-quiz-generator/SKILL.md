---
name: progressive-quiz-generator
description: Generate 5 quizzes with progressive difficulty and distinct sub-topics based on user reference data. Use when the user asks to create progressive tests, multi-level quizzes, or topic-focused assessments from study materials.
---
# Progressive Quiz Generator

A structured skill for creating 5 quizzes from user-provided reference data, ensuring progressive difficulty levels and distinct sub-topic coverage.

## When to Use
Use this skill when the user requests:
- Creating 5 quizzes of increasing difficulty from reference materials
- Designing multi-level assessments covering distinct sub-topics
- Transforming lecture notes or documents into progressive test sets

## Workflow Steps

1. **Analyze Reference Content**:
   - Extract core concepts, key terms, and main themes from the provided user material.
   - Divide the material into 5 distinct sub-topics or modules.

2. **Design Difficulty Ladder (5 Levels)**:
   - **Quiz 1 (Beginner - Conceptual Recall)**: Multiple choice / true-false questions focusing on basic definitions, facts, and foundational terms.
   - **Quiz 2 (Elementary - Basic Understanding)**: Fill-in-the-blanks or short answer questions testing comprehension of key concepts.
   - **Quiz 3 (Intermediate - Application)**: Scenario-based questions asking learners to apply principles to concrete examples.
   - **Quiz 4 (Advanced - Analysis & Comparison)**: Comparative questions requiring critical comparison between two or more concepts.
   - **Quiz 5 (Mastery - Synthesis & Problem Solving)**: Complex open-ended or case-study questions requiring synthesis and strategic reasoning.

3. **Format & Output**:
   - Provide clear answer keys, scoring rubrics, and detailed explanations for each quiz.
   - Format cleanly with Markdown headers and bullet points.

## Gotchas
- Ensure each of the 5 quizzes focuses on a distinct sub-topic to avoid repetitive questioning.
- Maintain a strict, smooth difficulty curve across Quiz 1 through Quiz 5.
