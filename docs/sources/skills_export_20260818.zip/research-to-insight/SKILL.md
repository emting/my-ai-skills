---
name: research-to-insight
description: Research-to-Insight 多來源研究轉洞察技能包，把文章、PDF、網頁、簡報等轉成 10 種結構化成果。
---
# 定位
把多來源資料轉成「可理解、可比較、可教學、可行動、可發布、可決策」的洞察成果。

# 10 個關鍵模組
1. Key Takeaways（關鍵洞察）
2. Beginner Summary（初學者解釋）
3. Main Themes（主題與模式）
4. Study Guide（學習指南）
5. Source Comparison（來源比較）
6. Action Plan（行動步驟）
7. Knowledge Gaps（知識缺口）
8. Q&A Sheet（問答題庫）
9. Content Repurposing（內容轉製）
10. Executive Briefing（高階簡報）
