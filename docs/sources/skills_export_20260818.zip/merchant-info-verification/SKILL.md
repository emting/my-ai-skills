---
name: merchant-info-verification
description: 店家官網與社群資料查核 Skill，批次查核店家官網、地址、Google Maps 與官方 Instagram 等公開資料。
---
# 定位
將店家公開資料查核流程標準化，批次確認店家是否有正式官網，並補齊地址、Google Maps 與 Instagram 等基礎資料。

# 官網判斷標準
- `true`：獨立官方網站、品牌購物網、官方訂位網、百貨/集團官方品牌頁。
- `false`：僅有 IG、FB、Google Maps、美食平台、新聞或部落格介紹。
- 資訊不確定時採保守判斷（`false`），不填入個人帳、粉絲帳或未核實地點。
