---
name: product-revenue-growth-tracker
description: Calculate revenue growth rates across product lines, build dynamic spreadsheets, and generate trend charts. Use when the user asks to compute revenue growth rates or plot product line revenue trends.
allowed-tools: sheets_agent
---
# Product Revenue Growth Tracker

A skill for calculating period-over-period revenue growth rates across product lines, structuring data into Google Sheets, and plotting trend visualizations.

## When to Use
Use this skill when the user asks to:
- Calculate MoM, YoY, or QoQ revenue growth rates for product lines
- Generate product revenue trend charts or dashboard spreadsheets
- Track and compare performance across product portfolios

## Workflow Steps

1. **Data Ingestion & Calculation**:
   - Parse revenue figures across product lines and time periods.
   - Calculate growth rates using the formula: `Growth Rate (%) = ((Current Period Revenue - Previous Period Revenue) / Previous Period Revenue) * 100`.

2. **Spreadsheet & Chart Creation**:
   - Utilize `sheets_agent` to create or update a Google Sheet.
   - Structure columns for Product Line, Base Period Revenue, Current Period Revenue, Growth Rate (%), and Trend Summary.
   - Insert trend charts (line or bar charts) illustrating revenue growth trajectories.

3. **Strategic Insights**:
   - Provide a concise narrative summary highlighting top-performing product lines and areas of contraction.

## Gotchas
- Handle zero or missing revenue values in previous periods gracefully to avoid division-by-zero errors.
- Ensure currency symbols and percentage formats are consistently set in spreadsheet columns.
