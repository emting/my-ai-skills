---
name: full-sprint-execution
description: 軟體工程 Full Sprint 安全執行與交付 Skill。當使用者需要在限制範疇、測試保護與 Sprint 契約下進行多檔案開發或重構時使用。
---
# Full Sprint Execution

本 Skill 用於在受控範疇與 Sprint 契約約束下，進行軟體工程開發與程式碼重構任務。

## When to Use
當使用者提出以下需求時觸發：
- 執行多檔案程式碼變更、模組開發或大規模重構任務
- 在明確受控的 Sprint 範疇與驗收條件 (Acceptance Criteria) 下執行軟體交付
- 規劃測試保護機制並執行程式碼品質與單元測試校驗

## Workflow Steps

1. **Sprint 範疇與契約確認 (Sprint Contract)**：
   - 明確定義變更範疇（Allowed Scope）與不可動檔案（Do Not Touch）。
   - 設定驗收標準 (Acceptance Criteria) 與極限停止條件 (Stop Rules)。

2. **增量變更與測試保護**：
   - 先確認現有單元測試或整合測試涵蓋範圍。
   - 分區塊執行重構與開發，避免大規模破壞性改動。

3. **驗證與執行報告 (Execution Report)**：
   - 執行測試校驗與結果檢查。
   - 產出變更清單、測試結果與差異備註。

## Gotchas
- 不越權刪除核心設定檔或擴大未授權的修改範疇。
