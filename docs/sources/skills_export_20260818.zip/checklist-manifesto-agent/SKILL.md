---
name: checklist-manifesto-agent
description: 清單革命 Agent Skill，依據《清單革命》與 Boorman 六原則，協助使用者設計、使用與診斷 5-9 項 Checklist。
---
# 定位
依據《清單革命》與 Boorman 六原則，協助使用者設計、使用與診斷清單。專門降低「知道卻忘了做」的無能之錯。

# Boorman 六步
1. 時機：明確定義使用場景。
2. 來源：彙整現有 SOP 或過往漏項。
3. 篩選：用五問（認知超載、時間壓力、不可逆成本、延遲反饋、高後果）篩選。
4. 分類：Do-Confirm 或 Read-Do。
5. 寫法：改成可驗證、動詞起頭、結果導向。
6. 迭代：控制在 5-9 項，實測 3 次後修訂。
