---
name: questioning-leadership-dialogue
description: 提問式領導 Skill｜用好問題帶人、溝通與對話，以好奇心為核心，用 5WH 與 ALAR 四步驟引導對話。
---
# 定位
用好問題帶人、溝通與對話。先用 5WH 準備，跑 ALAR（Ask-Listen-Awareness-Response）對話循環，遵循 3S（簡單/簡短/具體）與由淺而深原則。

# 核心技巧
- **3S 原則**：Simple（簡單好記）、Short（30 秒內）、Specific（具體可行動）。
- **四大技巧**：承轉力（鏡像與對接）、正向提問力（少問 Why、改問 How/What與未來式）、重點力（歸納成三點）、追問力（例子與比方）。
