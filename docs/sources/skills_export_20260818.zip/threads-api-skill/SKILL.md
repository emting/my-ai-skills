---
name: threads-api-skill
description: Comprehensive assistance with Meta's Threads API development for building applications that integrate with Meta's Threads social platform, including OAuth authentication, text/media/carousel posting, profile data retrieval, analytics insights, and webhook processing. Use when the user asks to integrate with Threads API, post to Threads, fetch Threads metrics, or set up Threads webhooks.
---

# Threads API Skill

Comprehensive assistance with Meta's Threads API development for building applications that integrate with the Threads social platform.

## Summary

The Threads API Skill provides practical guidance and code patterns for building integrations with Meta's Threads platform. It covers OAuth 2.0 authentication, text, image, video, and carousel publishing, user profile and post retrieval, analytics insights, webhooks, rate limiting, and error handling.

## When to Use

Use this skill when asked to:
- Build Threads API integrations or apps that read/write Threads content.
- Implement OAuth 2.0 authentication and token management for Threads.
- Publish text, image, video, or carousel posts to Threads.
- Retrieve user profiles, user posts, engagement metrics, or insights.
- Configure webhooks for real-time notifications (mentions, replies, etc.).
- Troubleshoot Threads API errors, status codes, or rate limits.

## Core Workflows and Endpoints

### 1. Authentication & Tokens
- **Authorization URL**: `https://threads.net/oauth/authorize?client_id={CLIENT_ID}&redirect_uri={REDIRECT_URI}&scope=threads_basic,threads_content_publish&response_type=code`
- **Exchange Code for Access Token**: `POST https://graph.threads.net/oauth/access_token`
  - Parameters: `client_id`, `client_secret`, `grant_type='authorization_code'`, `redirect_uri`, `code`

### 2. Publishing Posts
- **Text Post**: `POST https://graph.threads.net/v1.0/me/threads`
  - Body: `{"media_type": "TEXT", "text": "Your message"}`
- **Image Post**: `POST https://graph.threads.net/v1.0/me/threads`
  - Body: `{"media_type": "IMAGE", "image_url": "https://example.com/image.jpg", "text": "Caption"}`
- **Video Post (Two-stage)**:
  1. Create Container: `POST https://graph.threads.net/v1.0/me/threads` with `{"media_type": "VIDEO", "video_url": "...", "text": "..."}`
  2. Publish Container: `POST https://graph.threads.net/v1.0/me/threads_publish` with `{"creation_id": container_id}`
- **Carousel Post**: `POST https://graph.threads.net/v1.0/me/threads`
  - Body: `{"media_type": "CAROUSEL", "children": [{"media_type": "IMAGE", "image_url": "..."}, ...], "text": "Caption"}`

### 3. User Data & Post Retrieval
- **Fetch Profile**: `GET https://graph.threads.net/v1.0/me?fields=id,username,name,threads_profile_picture_url,threads_biography`
- **Fetch Recent Threads**: `GET https://graph.threads.net/v1.0/me/threads?fields=id,text,timestamp,media_url&limit=25`

### 4. Insights & Analytics
- **Thread Insights**: `GET https://graph.threads.net/v1.0/{thread_id}/insights?metric=views,likes,replies,reposts`

## Best Practices & Gotchas

- **Security**: Never expose client secrets or access tokens in client-side code. Always validate webhook signatures.
- **Two-stage Publishing**: Videos and carousels require container creation followed by container publishing to allow processing time.
- **Rate Limits**: Standard rate limit is 200 calls per hour per user. Monitor the `X-Business-Use-Case-Usage` response header.
- **Error Codes**: Code 190 indicates invalid/expired token; Code 32 indicates rate limit exceeded. Implement exponential backoff for retries.
