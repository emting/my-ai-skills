---
name: marketing-brief-competitor-analyst
description: Analyze marketing briefs, research real-time market competitors, and deliver strategic brand messaging positioning recommendations. Use when the user asks to analyze marketing briefs, research competitors, or refine brand positioning.
allowed-tools: google
---
# Marketing Brief & Competitor Analyst

A skill for parsing internal marketing briefs, conducting targeted web search research on key competitors, and formulating actionable brand positioning and message adjustment strategies.

## When to Use
Use this skill when the user asks to:
- Review a marketing brief and evaluate brand positioning
- Perform competitor research and market intelligence analysis
- Refine value propositions, messaging pillars, or marketing copy against market alternatives

## Workflow Steps

1. **Brief Parsing**:
   - Extract core brand goals, target audience demographics, value proposition, and unique selling points (USPs) from the provided marketing brief.

2. **Competitor Benchmarking**:
   - Utilize web search (`google:search`) to gather real-time data on top market competitors, their product messaging, pricing, and positioning.
   - Map out a Competitor Matrix comparing Features, Positioning, Strengths, Weaknesses, and Brand Messaging Tone.

3. **Strategic Brand Message Adjustment**:
   - Identify market gaps, white spaces, and points of differentiation.
   - Formulate refined Brand Messaging Pillars (Primary Message, Supporting Points, Tone Guidelines, and Call-To-Action).

## Gotchas
- Always base competitor insights on current web search data rather than static assumptions.
- Maintain an objective, balanced perspective when comparing brand strengths and weaknesses against competitors.
