---
name: interactive-skill-learning-curriculum
description: Research optimal learning methods for any target skill and design an interactive curriculum with videos, podcasts, reading materials, and checkable milestones. Use when the user asks to teach a skill, create a learning roadmap, or build an interactive course curriculum.
---
# Interactive Skill Learning Curriculum

任何技能的 0 到 1 最佳化學習地圖、多媒體資源整合與互動式課程設計。

## When to Use
- 使用者要求「教我（X）這項技能」。
- 需要設計包含影片、Podcast、閱讀材料與可勾選進度的完整學習課程。

## Steps
1. **技能拆解與學習路徑（Skill Decomposition）**：
   - 研究該技能的核心原理，將其拆解為「基礎概念 -> 核心操作 -> 實作專案 -> 高級應用」四個模組。
2. **多媒體資源檢索（Resource Curation）**：
   - 搜尋並精選高質量的免費/公開資源（優質影片、Podcast 單集、經典文章/官方文件）。
3. **互動式課程設計（Interactive Curriculum）**：
   - 設計循序漸進的週/日學習時間表。
   - 每單元包含：
     - [ ] 學習目標與核心概念
     - [ ] 推薦學習資源清單
     - [ ] 實作練習題 / 驗收小專案
     - [ ] 可勾選的學習進度（Checkable Markdown Checkboxes）
4. **學習教練互動（Coaching Loop）**：
   - 說明使用者可以在完成每個單元後回覆提問，獲得針對性解答與作業回饋。

## Gotchas
- 資源推薦著重質量而非數量，每個主題提供 1-2 個最優質選項即可，避免資源過載。
