---
name: app-performance-benchmark-optimizer
description: Establish app performance benchmarks, identify latency or memory bottlenecks, and execute measurable code optimizations with before/after reports. Use when the user asks to optimize app performance, profile latency, or fix performance bottlenecks.
---
# App Performance Benchmark Optimizer

應用程式效能建立測量基準、識別瓶頸與量化優化流程。

## When to Use
- 使用者要求改善 App 效能、分析程式碼瓶頸或進行效能優化。
- 需要進行前／後效能數據比較與報告。

## Steps
1. **建立基準測試（Establish Benchmark）**：
   - 撰寫或執行效能測試腳本（計算 Render 時間、記憶體占用、API 響應延遲或 CPU 負載）。
   - 記錄優化前的原始數據（Baseline Matrix）。
2. **瓶頸識別（Identify Bottlenecks）**：
   - 使用 Profiler 或語意分析找出前 3 個最顯著的效能瓶頸（如不必要的 Re-render、未解構的運算、未快取的 API 或 N+1 查詢）。
3. **目標優化（Targeted Optimization）**：
   - 在獨立測試分支上逐一重構瓶頸模組。
   - 每完成一項優化，重新執行基準測試驗證。
4. **定量對比與報告（Quantified Report）**：
   - 產出前後數據對比表格（例如：載入時間 1.2s -> 350ms，提升 70.8%）。
   - 限制最多執行 3 輪優化迭代，並輸出優化說明文件。

## Gotchas
- 每次優化必須保持功能等價（Functional Equivalence），並有單元測試或基準腳本驗證。
- 優化必須附帶客觀數據對比，不使用模糊的「感覺變快了」等描述。
