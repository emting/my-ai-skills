---
name: course-outline-source-enricher
description: Extract, verify, and format URLs and web references within course outlines, appending them into structured source lists. Use when the user asks to add web references, sources, or links to a course syllabus or outline.
---
# Course Outline Source Enricher

A skill that parses course outlines or syllabi, extracts all embedded or implied web links and references, verifies their validity, and formats them into a standardized "Data Sources / Reference Links" section.

## When to Use
Use this skill when the user asks to:
- Add web links, references, or source citations to a course outline or syllabus
- Extract and verify all URLs embedded across course modules
- Format course references into structured citation tables or resource lists

## Workflow Steps

1. **Extract Existing & Implied Links**:
   - Parse the course outline for raw URLs, hyperlinked terms, and mentioned publications/platforms.
   - For missing or broken URLs, search the web to locate official documentation or primary landing pages.

2. **Verify & Contextualize**:
   - Verify that each extracted link is valid and points to relevant course material.
   - Categorize links into categories (e.g., Required Reading, Supplementary Materials, Official Documentation, Tools/Platforms).

3. **Format & Append**:
   - Append a standardized "Data Sources & References" section to the end of the course outline.
   - Format each source as `[Source Title](URL) - Brief description of relevance`.

## Gotchas
- Do not fabricate URLs. Always ensure links exist and are fully grounded in search or user input.
- Keep the course outline structure intact while appending the reference section cleanly at the end.
