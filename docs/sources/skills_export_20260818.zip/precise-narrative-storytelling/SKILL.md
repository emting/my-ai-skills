---
name: precise-narrative-storytelling
description: 精準敘事 Skill｜把真實經驗變成好故事，用衝突找亮點、4P 萃取故事 DNA、故事九宮格三幕劇展開。
---
# 定位
把真實經驗轉換成好故事的可重用流程。用衝突（人與環境/人/自我/社會）切入、4P（Purpose/Problem/Promise/Practice）萃取骨架，並展開三幕劇與亮點邏輯檢查。

# 核心架構
- **衝突類型**：人與環境、人與人、人與自我、人與社會制度。
- **4P 骨架**：Purpose（目標）、Problem（阻礙）、Promise（決心）、Practice（付出）。
- **三幕劇比例**：第一幕 20%（建立）、第二幕 40%（阻礙）、第三幕 40%（轉念與行動）。
