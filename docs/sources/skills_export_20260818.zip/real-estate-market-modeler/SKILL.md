---
name: real-estate-market-modeler
description: Analyze real estate transactions, research local market trends and forecasts, and build a financial valuation/modeling Google Sheet. Use when the user asks to evaluate real estate deals, research nearby property trends, or build real estate valuation spreadsheets.
allowed-tools: google sheets_agent
---
# Real Estate Market Modeler

A skill for evaluating real estate transaction deals, researching surrounding neighborhood market trends via web search, forecasting price trajectories, and constructing property financial valuation models in Google Sheets.

## When to Use
Use this skill when the user asks to:
- Analyze a specific property/real estate transaction
- Research recent local housing market performance, price trends, and forecasts
- Build a real estate valuation or financial model in Google Sheets (cap rates, ROI, mortgage amortization, rental yields)

## Workflow Steps

1. **Transaction & Market Analysis**:
   - Extract property details: Location, Property Type, Square Footage, Price, Age, Zoning, etc.
   - Utilize web search (`google:search`) to gather recent local transaction data, neighborhood price trends, and economic/development forecasts.

2. **Financial Modeling (Google Sheets)**:
   - Call `sheets_agent` to construct a financial spreadsheet model.
   - Include key real estate metrics: Purchase Price, Down Payment, Estimated Rental Yield, Cap Rate, Debt Service Coverage Ratio (DSCR), Projected ROI, and 5-10 Year Price Appreciation Trajectories.

3. **Strategic Narrative**:
   - Summarize findings, market risks, upside potential, and actionable deal recommendations.

## Gotchas
- Ensure all market data and comparable property prices are cited from current search results.
- Verify formulas in the financial model (e.g. compounding appreciation, mortgage amortization).
