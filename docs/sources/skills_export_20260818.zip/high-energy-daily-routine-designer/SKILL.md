---
name: high-energy-daily-routine-designer
description: Audit personal lifestyle and design an optimized daily routine for high energy covering sleep, nutrition, exercise, social, creative, and career growth. Use when the user asks for life audit, daily routine design, or energy optimization plan.
---
# High Energy Daily Routine Designer

全面生活作息稽核與高精力理想每日作息系統設計。

## When to Use
- 使用者要求稽核生活狀況，設計保持充沛精力的理想一日作息。
- 涵蓋睡眠、營養、運動、社交、創作與職涯發展之平衡。

## Steps
1. **生活現狀診斷（Lifestyle Audit）**：
   - 透過 5-8 個關鍵問題釐清目前作息（睡眠時間、飲食習慣、運動頻率、高能量/低能量時段）。
2. **六大維度模組化設計（6-Dimension Architecture）**：
   - **睡眠與生物鐘**：固定起床/入睡時間與光照暴露。
   - **營養與水份**：穩定血糖波動的飲食架構。
   - **運動與修復**：符合使用者節奏的運動安排（Zone 2 / 伸展）。
   - **深度工作與職涯**：匹配個人最高精力時段的 Deep Work Block。
   - **創作與成就感**：無壓力自我表達時間。
   - **社交與連結**：優質高品質互動。
3. **產出個人化時間表（Schedule Blueprint）**：
   - 輸出兼具彈性與執行力的「高精力一日作息時間表」與「週循環調整機制」。

## Gotchas
- 作息設計必須符合真實人性和習慣循序漸進，避免設計過度嚴苛、無法維持的完美計畫。
