---
name: startup-venture-builder
description: Startup Venture Builder for opportunity discovery, market validation, MVP roadmap, business modeling, sales system, and investor stress testing. Use when the user asks for startup idea validation, business model design, MVP roadmap, landing page copy, or startup stress testing.
---
# Startup Venture Builder

A comprehensive skill for transforming early-stage business ideas into validated, market-ready, and monetizable ventures through a 12-phase framework.

## When to Use

Use this skill when the user asks to:
- Evaluate, discover, or validate startup ideas and market opportunities
- Design business models, pricing strategies, and revenue models
- Plan a 30-day MVP roadmap or minimal validation process
- Create landing page copy, sales systems, or customer personas
- Conduct growth planning, content strategy, or investor stress testing

## Core Workflow

Recommended execution order: Focus on Phase 1 (Opportunity Discovery) -> Phase 3 (Problem Validation) -> Phase 5 (30-day MVP) -> Phase 12 (Stress Test) first. Proceed to sales and content engines after core validation.

### Phase 1: Idea Discovery
Identify high-demand, low-competition, monetizable business concepts. Evaluate pain intensity, willingness to pay, and feasibility.

### Phase 2 & 3: Market & Problem Validation
Analyze market size, competitors, and industry trends. Test whether the problem is severe enough that customers will pay for a solution.

### Phase 4 & 5: Business Model & 30-Day MVP
Design pricing tiers, customer acquisition channels, cost structures, and a 30-day MVP execution timeline with clear success/failure metrics.

### Phase 6 to 10: Go-To-Market Systems
Draft landing page copy, customer personas, 90-day growth roadmap, sales outreach scripts, and a 30-day content calendar.

### Phase 11 & 12: AI Team Simulation & Investor Stress Test
Simulate C-level perspectives (CEO, CMO, PM, Sales, CS) and conduct skeptical investor Q&A to identify failure risks and mitigation plans.

## Fact & Assumption Tagging

Always categorize statements using these explicit markers:
- Fact: Supported by verified data or user experience
- Deduction: Derived from market logic
- Hypothesis: Requires empirical validation (MVP, interviews, sales test)

## Gotchas

- Do not attempt all 12 phases in a single turn unless explicitly requested.
- Distinguish true business opportunities from mere unverified ideas.
- Keep output concise and actionable; avoid generic startup jargon.
