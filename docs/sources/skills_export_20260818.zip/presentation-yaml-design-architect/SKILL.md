---
name: presentation-yaml-design-architect
description: Transform presentation topics or draft text into a structured presentation design blueprint in YAML format (PRESENTATION_DESIGN.yaml) specifying global design specs, color schemes, layout rules, page-by-page visual descriptions, and content generation prompts. Use when the user asks to generate presentation design blueprints, YAML slide architectures, or structured presentation visual specs.
---
# Presentation YAML Design Architect

Transforms presentation topics or raw text into a structured, executable presentation design blueprint in YAML format (`PRESENTATION_DESIGN.yaml`).

## When to Use

Use this skill when the user asks to:
- Create a presentation design specification or blueprint in YAML format
- Define global slide design specs (color palette, typography, grid rules, atmosphere)
- Plan page-by-page layout styles, visual descriptions, and content generation prompts for slides

## Workflow

1. **Atmosphere & Tone**: Analyze the topic/content to determine the core atmosphere adjectives and theme.
2. **Global Design Specifications**: Define specific Hex color codes (background, text, accent, secondary), typography recommendations (heading, body, data), and layout/grid rules.
3. **Slide Breakdown & Narrative Flow**: Organize the slide sequence logically (cover, introduction, core concepts, data visualization, conclusion).
4. **Visual Mapping & Prompt Generation**: For each slide (`p1`, `p2`, ...), detail the `type`, `layout_style`, `visual_description`, and content/`generation_prompt`.
5. **YAML Export**: Produce strict, valid YAML code matching the exact schema.

## YAML Output Schema (`PRESENTATION_DESIGN.yaml`)

```yaml
global_design:
  atmosphere: "[3 key adjectives, e.g., Futuristic, Clean, Authoritative]"
  color_scheme:
    background: "[Hex, e.g., #0F172A]"
    text: "[Hex, e.g., #F8FAFC]"
    accent: "[Hex, e.g., #38BDF8]"
    secondary: "[Hex, e.g., #64748B]"
  typography:
    heading: "[Font recommendation, e.g., Inter Bold / Noto Sans TC Bold]"
    body: "[Font recommendation, e.g., Inter Regular / Noto Sans TC Regular]"
    data: "[Font recommendation, e.g., JetBrains Mono]"
  layout_rules:
    navigation: "[Navigation placement, e.g., Top-right progress bar]"
    image_style: ["[Image treatment]", "[Chart style]"]
    layout_design: ["[Grid system]", "[Alignment rules]"]
    decorative_elements: "[Description of accents/decorations]"

slides:
  p1:
    type: "[Slide type, e.g., Cover]"
    layout_style: "[Layout name, e.g., Centered Hero]"
    visual_description: "[Detailed visual composition and graphic elements]"
    content:
      title: "[Title]"
      subtitle: "[Subtitle / Description]"
  p2:
    type: "[Slide type, e.g., Concept Breakdown]"
    layout_style: "[Layout name, e.g., Split 2-Column]"
    visual_description: "[Detailed visual composition and graphic elements]"
    content:
      title: "[Title]"
      generation_prompt: "[Detailed content generation prompt]"
  # Extend p3, p4, etc., as needed
```

## Scope & Boundaries

- **In Scope**: Generating complete YAML blueprints, defining Hex colors, font categories, visual composition descriptions, and content generation prompts.
- **Out of Scope**: Generating actual image binary files, generating full presentation scripts, or exporting directly to PPTX/Keynote binary formats.

## Gotchas

- Strictly preserve the YAML keys (`global_design`, `atmosphere`, `color_scheme`, `typography`, `layout_rules`, `slides`).
- Provide concrete Hex color codes rather than vague color names.
