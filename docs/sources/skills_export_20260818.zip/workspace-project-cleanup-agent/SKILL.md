---
name: workspace-project-cleanup-agent
description: Audit workspace projects, identify abandoned or duplicate work, and safely execute cleanup on git-tracked branches. Use when the user asks to clean up workspace, find abandoned or duplicate projects, or organize codebase projects.
---
# Workspace Project Cleanup Agent

工作區專案與程式碼庫的安全自動化稽核與清理流程。

## When to Use
- 使用者要求稽核工作區中的專案、清理廢棄或未完成的工作。
- 使用者希望整合重複程式碼或建立工作區清理計畫。

## Steps
1. **工作區掃描（Workspace Audit）**：
   - 掃描工作區內所有專案目錄，分析 Git 狀態（最後提交時間、未提交變更、未追蹤檔案）。
   - 識別「已放棄」（>6 個月未更新）、「重複」（類似目錄結構）與「未完成」（有 open TODO / Uncommitted changes）專案。
2. **隔離與備份（Branch Containment & Backup）**：
   - 自動切換至全新 Git 清理分支（如 `ai-cleanup-draft`），絕不直接在主分支（main/master）上作業。
3. **分級執行（Classified Execution）**：
   - **低風險（Direct Action）**：自動刪除空目錄、過期建置快取（`node_modules`、`.cache`、`dist` 可重新 install/build 者）、移除過期格式化暫存檔。
   - **高風險（User Proposal）**：涉及程式碼刪除、目錄搬移或專案合併，先寫入 `cleanup_plan.md`，列出刪除原因與恢復方法，等待使用者審核。
4. **輸出清單與彙報（Reporting）**：
   - 產出結構化清理報告，分類列出「已處理項目」與「待使用者確認項目」。

## Gotchas
- 嚴禁直接執行 `rm -rf` 刪除未受 Git 追蹤的原始碼檔案。
- 高風險檔案異動必須產生提案文件（`cleanup_plan.md`），等使用者確認後才可執行。
