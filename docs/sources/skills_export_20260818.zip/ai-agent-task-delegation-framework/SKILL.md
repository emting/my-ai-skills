---
name: ai-agent-task-delegation-framework
description: AI Agent 任務委派總則（雷小蒙模式），將重複任務交給 Agent 跑，人只下指令與驗收（<2 小時）。
---
# 定位
AI Agent 任務委派母框架。將重複發生的任務（每週≥1次）拆成技能模組交給 Agent 自動執行，人僅於待審區進行驗收放行與反饋迭代。

# 核心步驟
1. 盤點重複任務並計算人力 vs. Agent 成本。
2. 拆解為技能模組（SKILL.md 規格）。
3. Agent 背景排程執行，產出落地至待審區。
4. 人工驗收（每日 <2 小時），將修正回寫至 Skill。
