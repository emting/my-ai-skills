---
name: pdf-study-guide-generator
description: Transform class notes into a comprehensive structured study guide, generate 5 practice questions, and compile them into a PDF. Use when the user asks to summarize notes into a PDF study guide with practice questions.
---
# PDF Study Guide Generator

A skill that takes lecture or class notes, synthesizes them into a structured study guide with key takeaways and 5 practice exercises, and exports the final document into a formatted PDF.

## When to Use
Use this skill when the user asks to:
- Convert class notes or lecture transcripts into a complete PDF study guide
- Summarize study material and attach 5 practice questions or review exercises
- Generate structured PDF revision guides for exam preparation

## Workflow Steps

1. **Information Extraction & Structuring**:
   - Synthesize class notes into logical sections: Executive Summary, Key Terminology, Core Concepts, and Detailed Study Modules.

2. **Practice Exercises Creation**:
   - Append 5 targeted practice questions at the end of the guide (covering multiple choice, short explanation, and application problems) along with detailed answer keys.

3. **PDF Generation**:
   - Write Python script utilizing ReportLab or FPDF2 to generate a cleanly styled PDF document.
   - Save the output PDF file to Google Drive and return the shareable web view link to the user.

## Gotchas
- Ensure all technical terms and formulas are clearly formatted in the PDF.
- Verify PDF layout formatting (margins, font sizes, page breaks) so text does not overlap or spill over awkwardly.
