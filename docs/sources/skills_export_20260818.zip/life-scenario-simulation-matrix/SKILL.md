---
name: life-scenario-simulation-matrix
description: Conduct a 50-question life audit and simulate 30-year life trajectories across career, health, exercise, and relationship variables into structured matrices. Use when the user asks for a 50-question life survey or 30-year life scenario simulation.
---
# Life Scenario Simulation Matrix

人生深度訪談、跨維度未來情境模擬與結構化決策矩陣建構。

## When to Use
- 使用者希望回答 50 個人生問題並進行長週期未來模擬。
- 需要比對不同職涯、飲食、運動與伴侶選擇的 30 年軌跡。

## Steps
1. **50 問精準診斷（50-Question Life Survey）**：
   - 分批提出 50 個涵蓋「職涯、財務、健康、關係、價值觀、風險偏好」的深度問題（每次提問 5-10 題以避免認知過載）。
2. **多維度變數設定（Variable Configuration）**：
   - 設定對照組變數：職涯路徑（現狀 vs 創業）、運動頻率（1天/2天/7天）、飲食模式、伴侶關係。
3. **情境交叉樹模擬（Scenario Tree Simulation）**：
   - 推演 30 年間在不同變數組合下的「財務累積、健康指數、心理滿意度與風險暴露」。
4. **試算表矩陣輸出（Structured Matrix Output）**：
   - 將模擬結果彙整為結構化表格（可匯出為 CSV 或 Google Sheet）。
   - 強調定性趨勢與槓桿節點，並明確標示推演假設與不確定性。

## Gotchas
- 模擬結果屬於啟發性策略工具，絕不將推演數值作為絕對預測事實呈現。
