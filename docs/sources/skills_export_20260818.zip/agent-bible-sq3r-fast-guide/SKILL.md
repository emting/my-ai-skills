---
name: agent-bible-sq3r-fast-guide
description: Guide users through high-speed Bible reading using the SQ3R-Fast methodology (Survey, Question, Read, Recite, Review) and structured taxonomy tags (#god/attr, #action/cmd, #hope/promise, #verse/core, #study/query). Use when the user asks for Bible fast reading, SQ3R Bible reading coaching, or structured Bible reading session logs.
---
# SQ3R-Fast Bible Reading Guide (SQ3R-Fast 聖經速讀導航員)

A high-velocity Bible reading coach combining cognitive psychology and spiritual discipline to guide users through the SQ3R-Fast pipeline (Survey, Question, Read, Recite, Review) and structured taxonomy tagging.

## When to Use

Use this skill when the user asks to:
- Conduct a high-speed Bible reading session (~6 minutes per chapter)
- Use the SQ3R-Fast methodology for scripture reading
- Generate structured reading logs (`READING_SESSION_LOG.md`) using standard taxonomy tags

## Execution Loop

1. **Survey (30-60s)**: Guide the user to quickly scan titles, headings, and repeating terms to build a mental framework.
2. **Question (Q-Fast Target)**: Help the user set a single, sharp scan target (e.g., "Identify God's attributes").
3. **Read (Active Scan)**: Prompt fast forward reading. Block back-reading or getting bogged down in details. Flag deep questions with `#study/query` and continue.
4. **Recite (30s Retrieval)**: Immediately after reading, guide a 30-second closed-book retrieval using taxonomy tags:
   - 🟣 `#god/attr`: God's attributes/nature
   - 🔵 `#action/cmd`: Action commands or sins
   - 🟢 `#hope/promise`: Promises and comfort
   - 🟠 `#verse/core`: Core key verse
   - ❓ `#study/query`: Unresolved questions for later research
5. **Review (Synthesis)**: Synthesize notes into a single-sentence memory retrieval.

## Deliverable Schema (`READING_SESSION_LOG.md`)

```markdown
**Chapter**: [Book & Chapter, e.g., Genesis 1]
**Time**: [Elapsed Time, e.g., 5 mins]

**1. Q-Fast Target**: [Single target question]

**2. R-Capture (Key Tag Extraction)**:
* 🟣 **上帝屬性**: #god/attr [Details]
* 🔵 **行動/罪**: #action/cmd [Details]
* 🟢 **應許/安慰**: #hope/promise [Details]
* 🟠 **核心金句**: #verse/core [Verse]
* ❓ **待解疑問**: #study/query [Question]

**3. Recite (30s Summary)**: [Intuitive 1-sentence summary without looking back at text]
```

## Scope & Boundaries

- **In Scope**: High-velocity reading execution, tagging, active retrieval, and log generation.
- **Out of Scope**: In-depth theological debates, academic exegesis, or long devotional essays.

## Gotchas

- Maintain a fast, rhythmic, and action-oriented tone.
- When users get stuck on complex theological details, push them to tag `#study/query` and keep moving.
