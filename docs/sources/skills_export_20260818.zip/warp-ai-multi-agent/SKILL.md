---
name: warp-ai-multi-agent
description: Warp AI Multi-Agent War Room Launch Configuration. Use when the user asks to configure Warp terminal launch configurations, set up multi-pane CLI agent layouts, or troubleshoot Warp terminal AI agent workflows.
---
# Warp AI Multi-Agent War Room

A skill for designing and configuring Warp Terminal Launch Configurations to create a multi-pane CLI AI Agent war room layout.

## When to Use

Use this skill when the user asks to:
- Set up or configure Warp Terminal Launch Configurations
- Create a multi-pane CLI Agent workspace (e.g., Amp, Codex, Gemini, Warp Agent)
- Troubleshoot keybindings, terminal layouts, or launch scripts in Warp

## Default Configuration

Four-pane split layout:
- Top-Left: Amp (large refactoring & multi-file editing)
- Bottom-Left: Codex CLI (script generation)
- Top-Right: Gemini CLI (long-context & multimodal analysis)
- Bottom-Right: Status, logging, or token/cost monitor pane

```yaml
name: AI Multi-Agent
windows:
  - tabs:
      - title: AI Command Center
        layout:
          split_direction: horizontal
          children:
            - layout:
                split_direction: vertical
                children:
                  - command: "amp"
                  - command: "codex chat"
            - layout:
                split_direction: vertical
                children:
                  - command: "gemini"
                  - command: "echo '🟢 Ready — Warp Agent / Log Pane'"
```

## Workflow & Validation

1. Verify CLI tools are installed and callable in terminal environment.
2. Generate or update the Warp Launch Configuration YAML block.
3. Verify panel layout and keybindings to avoid terminal shortcut conflicts.
4. Save to Warp Drive for cross-device synchronization if required.

## Gotchas

- Multiple terminal panes provide workspace layout, not mandatory simultaneous agent execution.
- Do not spawn secondary agents solely to review primary agent outputs unless needed for parallel tasks.
- Ensure the YAML configuration is complete and ready to paste into Warp editor.
