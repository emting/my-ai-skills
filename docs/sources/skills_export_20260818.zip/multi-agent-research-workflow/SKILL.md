---
name: multi-agent-research-workflow
description: An advanced multi-agent research workflow inspired by Claude Research architecture, enhanced with Full Sprint engineering controls. Use when conducting deep multi-perspective research, executing parallel subagent investigation tasks, or synthesizing research into actionable software engineering sprint contracts.
---
# Multi-Agent Research Workflow

A structured framework based on the Claude Research architecture (LeadResearcher, Subagents, CitationAgent, Memory/Checkpoints) and integrated with Full Sprint execution controls for performing deep, rigorous multi-perspective research and engineering delivery.

## When to Use

Use this skill when:
- The user requests deep research on a complex, multi-faceted topic requiring multiple sources.
- The task requires dividing a broad topic into distinct sub-topics researched in parallel.
- High accuracy, comprehensive coverage, and strict inline source citations ([Title](URL)) are required.
- The research leads into software development, code refactoring, or technical implementation (bridging with Full Sprint execution).

## Core Roles & Workflow

### 1. LeadResearcher (Planning & Strategy)
1. **Analyze Query & Classify Complexity**:
   - **Low**: Single-entity lookup. Execute directly without subagent overhead.
   - **Medium**: 2-3 sub-questions. Create 2-3 parallel research sub-tasks.
   - **High**: Multi-faceted or multi-entity investigation. Create 3-5 parallel sub-tasks.
2. **Strategy & Checkpoint Initialization**:
   - Deconstruct the user query into distinct, non-overlapping sub-queries.
   - Initialize a task tracking checklist (e.g. `task.md`) to maintain state and record milestones.

### 2. Subagents (Parallel Research & Tool Execution)
1. **Parallel Execution**:
   - Dispatch up to 3-5 concurrent subagents (`invoke_subagent`) to investigate specific sub-topics.
2. **Iterative Search & Retrieval**:
   - Subagents query web sources, Google Workspace (Drive, Gmail, Docs), or code execution tools.
   - Evaluate results critically for source quality, authority, and freshness.
3. **Synthesis & Refinement**:
   - Subagents summarize key findings, extract direct facts, and retain raw source URLs for grounding.

### 3. CitationAgent (Fact Grounding & Citation)
1. **Map Claims to Concrete Sources**:
   - Verify every factual claim against the returned tool outputs.
   - Every claim derived from external or internal tools MUST include clickable inline markdown citations: `[Title](URL)`.
2. **No Uncited Claims**:
   - Eliminate or rephrase ungrounded claims where no source URL exists.

### 4. Sprint Bridge & Engineering Handoff (Full Sprint Alignment)
When research scope touches technical implementation, refactoring, or code deliverables:
1. **Draft Sprint Contract**:
   - Define **Allowed Scope** and **Do Not Touch** boundaries.
   - Specify **Acceptance Criteria** and **Stop Rules**.
2. **Test Protection & Verification Strategy**:
   - Define expected unit/integration test coverage before executing code changes.
3. **Execution Report Generation**:
   - Produce a change manifest, test validation output, and delta summary for seamless handoff to `full-sprint-execution`.

### 5. Memory & Quality Control
1. **Progress Verification**:
   - Update checklist status upon completing each research milestone.
2. **LLM-as-Judge Evaluation**:
   - Assess research output against key criteria: Factuality, Citation Accuracy, Coverage Completeness, and Source Diversity.
3. **Retry & Fallback**:
   - If a sub-topic has low coverage or failed search, perform a targeted follow-up lookup before finalizing.

## Gotchas & Principles

- **Avoid Over-Engineering**: Do not spawn 3-5 subagents for simple lookups. Match subagent count to query complexity.
- **Strict Citation Rules**: Never use bracketed numeric references like `[1]` or `[1, 2]`. Always use `[Source Title](URL)`.
- **Prevent Duplication**: Ensure subagent queries do not overlap so research context remains efficient and focused.
- **Respect Rate & Execution Limits**: Limit concurrent tool calls and manage subagent payloads cleanly.
