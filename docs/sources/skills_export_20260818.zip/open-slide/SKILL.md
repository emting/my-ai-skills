---
name: open-slide
description: Create, draft, edit, and manage web-native React presentations using the open-slide framework. Use when the user requests creating slides, building presentation decks with React/open-slide, editing slide components, or exporting open-slide presentations.
---

# Open Slide

Framework and authoring guide for building agent-native React slide decks with open-slide.

## Summary

`open-slide` is an open-source, React-based presentation framework built specifically for AI agents and developer-centric workflows. Presentations in open-slide are written as standard React components rendering on a fixed 1920 × 1080 canvas, with automatic scaling, hot reloading, present mode, and in-browser inspection comments.

## When to Use

Use this skill when:
- Creating a new presentation deck or slide project using `open-slide`
- Writing or editing React slide components under `slides/<deck-id>/index.tsx`
- Structuring slide layouts, typography, color palettes, or animations for 1920 × 1080 slides
- Applying in-browser inspector comments (`@slide-comment`) to slide code
- Exporting open-slide decks to static HTML or PDF format

---

## Core Principles & Canvas Contract

1. **Fixed Canvas Resolution**: Every page renders inside a `1920 × 1080` pixel viewport.
2. **React Page Architecture**: Decks are standard React applications. Slides default-export an array of `Page` components.
3. **No DSL Constraints**: Authors can use standard HTML, CSS, Tailwind CSS, Lucide icons, Framer Motion, and SVGs.
4. **Hot Reload & Presenter Mode**: Includes live preview, speaker notes, preview of upcoming slides, and keyboard navigation.

---

## Workflow Steps

### Step 1: Initialize Deck
To create a new slide workspace:
```bash
npx @open-slide/cli init <deck-name>
cd <deck-name>
pnpm dev
```

### Step 2: Deck Scoping & Structure
Before writing slide code, establish:
- **Topic & Audience**: Target domain and visual tone (e.g., modern tech, minimalist, dark mode, corporate).
- **Page Count & Density**: Total slides (typically 5–15 pages) and text density per slide.
- **Color Palette & Typography**:
  - Primary, background, text, and accent colors
  - Consistent type scale suited for 1920 × 1080 canvas (e.g., Title: 48px–72px, Body: 20px–28px).

### Step 3: Slide Component Authoring
Slide files reside under `slides/<deck-id>/index.tsx`.

```tsx
import React from 'react';

export const Slide1 = () => (
  <div className="w-[1920px] h-[1080px] bg-slate-900 text-white flex flex-col justify-center items-center p-16">
    <h1 className="text-6xl font-bold mb-6 text-blue-400">Open Slide Title</h1>
    <p className="text-2xl text-slate-300 max-w-3xl text-center">
      Agent-native presentation framework built on React.
    </p>
  </div>
);

export const Slide2 = () => (
  <div className="w-[1920px] h-[1080px] bg-slate-900 text-white p-16 flex flex-col justify-between">
    <h2 className="text-4xl font-semibold text-blue-400">Key Features</h2>
    <div className="grid grid-cols-3 gap-8 my-auto">
      <div className="bg-slate-800 p-8 rounded-xl border border-slate-700">
        <h3 className="text-2xl font-bold mb-4">React Native</h3>
        <p className="text-slate-300">Full power of React and Tailwind CSS.</p>
      </div>
      <div className="bg-slate-800 p-8 rounded-xl border border-slate-700">
        <h3 className="text-2xl font-bold mb-4">Agent Driven</h3>
        <p className="text-slate-300">Designed for natural language generation.</p>
      </div>
      <div className="bg-slate-800 p-8 rounded-xl border border-slate-700">
        <h3 className="text-2xl font-bold mb-4">Inspector & Export</h3>
        <p className="text-slate-300">In-browser comments & instant PDF export.</p>
      </div>
    </div>
  </div>
);

export default [Slide1, Slide2];
```

### Step 4: In-Browser Comments & Edits
Use the dev server inspector to leave `@slide-comment` markers on elements, then update slide components accordingly:
- Read comment markers in `slides/<deck-id>/index.tsx`.
- Apply requested changes (e.g., adjust font size, change color, update layout).
- Remove completed comment markers.

### Step 5: Exporting & Publishing
Build and export presentations:
- **Static Build**: `pnpm build`
- **PDF Export**: Export present mode views via static site or Playwright screenshot script.

---

## Best Practices & Gotchas

- **Always maintain 1920 × 1080 proportions**: Use explicit width (`1920px`) and height (`1080px`) or full-container flex/grid bounds to prevent content clipping.
- **Readable Type Contrast**: Ensure text contrast ratios meet accessibility standards on dark or light backgrounds.
- **Modular Component Design**: Break complex slide diagrams or charts into reusable React components.
- **Avoid Content Overflow**: Keep text concise per slide to maintain visual balance on large screens.
