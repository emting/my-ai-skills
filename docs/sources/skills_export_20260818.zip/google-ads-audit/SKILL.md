---
name: google-ads-audit
description: Google Ads 廣告帳戶與成效審查/稽核 Skill。當使用者需要審查 Google Ads 帳戶架構、關鍵字策略、成效指標 (CPA/ROAS) 或優化廣告文案時使用。
---
# Google Ads Audit

本 Skill 用於評估與稽核 Google Ads 廣告帳戶成效、關鍵字與廣告架構，提供改善建議與優化清單。

## When to Use
當使用者提出以下需求時觸發：
- 審查或稽核 Google Ads 廣告帳戶成效與架構
- 評估關鍵字搜尋意圖、品質分數與負向關鍵字清單
- 分析 CPA、CPC、CTR 與 ROAS 廣告指標並提出調整方案

## Workflow Steps

1. **帳戶架構與成效資料盤點**：
   - 檢視 Campaign、Ad Group、Keywords 與 Ad Copy 之結構分集。
   - 盤點核心指標：Impression, CTR, CPC, CPA, Conversion Rate, ROAS。

2. **關鍵字與意圖稽核**：
   - 區分高意圖關鍵字與廣泛比對（Broad Match）浪費風險。
   - 檢查 Negative Keywords（排除關鍵字）設置是否完整。

3. **文案與 landing page 體驗**：
   - 檢查廣告標題與內文是否包含關鍵字與具體 CTA。
   - 評估到達頁面（Landing Page）與廣告訴求之一致性。

4. **稽核報告與優化方案產出**：
   - 提供 3 大改進重點與具體微調步驟（如預算轉移、廣告痛點重構）。

## Gotchas
- 著重可驗證的數據邏輯與成效改進，避免給予模糊的通泛廣告建議。
