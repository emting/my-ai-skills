---
name: game-inspiration-world-builder
description: Generate 3D world inspiration concepts and autonomously build matching game code and assets. Use when the user asks to generate 3D world concepts, design game worlds, or build a game matching visual inspiration images.
---
# Game Inspiration World Builder

自 3D 視覺靈感至遊戲開發的自主建構流程。

## When to Use
- 使用者要求生成 3D 世界靈感圖或視覺概念。
- 使用者指示「打造一款與靈感圖視覺一致的遊戲」。

## Steps
1. **概念與視覺生成（Concept Generation）**：
   - 使用圖片生成工具產出 30 張風格統一的 3D 遊戲世界靈感圖（涵蓋材質、光影、場景構圖）。
2. **架構設計（Architecture Planning）**：
   - 提取靈感圖中的核心視覺元素（色調、物件形狀、環境氛圍）。
   - 選擇合適的 WebGL / Three.js / Canvas 遊戲引擎架構，建立模組化專案目錄。
3. **自主程式碼建構（Autonomous Build Loop）**：
   - 建立 3D 場景、渲染器、控制鏡頭與光影系統。
   - 逐步實現玩家互動、碰撞偵測與核心玩法。
4. **品質驗收與停止條件（Validation & Stop Rule）**：
   - 設定上限 5 輪迭代修正。
   - 確認畫面流暢度（FPS >= 60）與基本遊戲迴圈可運作後停止，並輸出階段成果與部署連結。

## Gotchas
- 避免設定「做到極致完美前不停止」的開放式語句，必須包含明確的迭代上限（如 5 輪）以防止無窮迴圈。
