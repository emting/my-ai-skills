---
name: renovation-expense-tracker
description: Process renovation receipts, categorize contractor engineering items and costs, and generate an expense tracking Google Sheet. Use when the user asks to organize renovation receipts or build a renovation project cost tracking spreadsheet.
allowed-tools: sheets_agent
---
# Renovation Expense Tracker

A skill for parsing home/office renovation receipts and contractor invoices, categorizing engineering items, and building a structured budget tracking spreadsheet in Google Sheets.

## When to Use
Use this skill when the user asks to:
- Process uploaded interior design/renovation receipts or invoices
- Categorize contractor expenses (Demolition, Electrical, Plumbing, Carpentry, Painting, Fixtures, etc.)
- Build an engineering item & cost tracking Google Sheet with budget variance metrics

## Workflow Steps

1. **Receipt & Line-Item Extraction**:
   - Parse renovation receipts, contractor estimates, or line items.
   - Standardize key fields: Date, Contractor/Vendor Name, Engineering Category (e.g., 拆除工程, 水電工程, 木作工程, 泥作工程, 油漆工程), Description, Unit Cost, Quantity, Total Amount, Payment Status (Paid / Pending).

2. **Google Sheet Construction**:
   - Call `sheets_agent` to build or update a Google Sheet.
   - Structure a "Summary Dashboard" tab (Total Estimated Budget, Total Actual Expense, Variance) and a "Line Items Detail" tab.
   - Apply formatting for monetary currency and expense totals.

## Gotchas
- Categorize items consistently across vendors (e.g., group all electrical wiring under Electrical Engineering).
- Keep track of tax/VAT inclusions vs exclusions where applicable.
