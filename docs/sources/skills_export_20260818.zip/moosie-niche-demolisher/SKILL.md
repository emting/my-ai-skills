---
name: moosie-niche-demolisher
description: 【Research Skill】Moosie｜Category-of-One Niche Demolisher，找出高需求、低競爭的 Instagram 補教品牌子定位。
---
# 定位
把 Moosie Education 的 Instagram 從一般補習班帳號重新定位成 Category-of-One。分析市場擁擠區、家長真實需求，建立難以複製的內容切角與矩陣。

# 核心架構
1. **擁擠區與痛點分析**：避開泛用「有趣全美語」訴求，鎖定家長對「孩子聽得懂但不敢開口」的深層焦慮。
2. **Category-of-One 定位**：建立定位句與比較矩陣。
3. **內容支柱與系列**：規劃「孩子敢開口的瞬間」、「小班全美語課堂觀察」等支柱，產出 Reels hook、carousel 標題與 IG bio。
