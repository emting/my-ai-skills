---
name: product-launch-gate-checklist
description: 產品上線關卡檢查 Skill｜八階段 Exit Criteria，核對 Phase 0-7 上線關卡條件，判定 Go/No-Go。
---
# 定位
產品上線關卡檢查器。核對 Phase 0-7（發想/需求/設計/開發/測試/上線前/發佈/監控）之 Exit Criteria，給予 Go、No-Go 或有條件 Go。

# 執行步驟
1. 定位目前 Phase。
2. 逐條核對 Exit Criteria（已達成/未達成/需確認）。
3. 產出結論，僅列出阻擋項與最小完成動作（未確認項不當作通過）。
