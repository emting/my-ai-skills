---
name: product-idea-scoring-matrix
description: Generate 100 product or SaaS ideas based on skills/interests and score each across market demand, execution difficulty, differentiation, startup cost, and time-to-first-revenue. Use when the user asks for 100 product ideas, SaaS ideation, or startup idea scoring matrix.
---
# Product Idea Scoring Matrix

基於技能與興趣的 100 個產品點子生成、5 維度定量評分與 MVP 路線圖。

## When to Use
- 使用者要求產生 100 個產品或創業點子。
- 需要依照市場需求、執行難度、差異化、成本與取勝時間進行客觀評分。

## Steps
1. **背景與技能輸入（Skill/Interest Context）**：
   - 提取使用者的核心技能、領域知識與興趣背景。
2. **100 個點子發想（Idea Generation）**：
   - 涵蓋微型 SaaS、AI 工具、自動化服務、數位產品與垂直社群產品。
3. **5 維度定量評分（5-Dimension Matrix Scoring）**：
   - 為每個點子建立 1-10 分評估：
     - 市場需求（Market Demand）
     - 執行難度（Execution Difficulty）
     - 差異化程度（Differentiation）
     - 啟動成本（Startup Cost）
     - 距離首筆收入時間（Time to First Revenue）
4. **Top 5 精選與驗證行動（Top Picks & Action Plan）**：
   - 篩選綜合得分最高的 Top 5 點子，提供最小可行性產品（MVP）驗證步驟與測試頁面文案。

## Gotchas
- 表格必須清晰美觀，支援分組與排序，方便使用者直接篩選決策。
