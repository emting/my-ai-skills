---
name: mimo-hermes-openclaw-diagnosis
description: 協助設定與排錯 Xiaomi MiMo、Hermes Agent、OpenClaw 的模型連線，確認 API Key 類型、Base URL、provider 名稱與模型名稱。
---
# 定位
協助設定與排錯 Xiaomi MiMo、Hermes Agent、OpenClaw 的模型連線。核心任務是先確認 API Key 類型、Base URL、provider 名稱與模型名稱是否成對正確。

# 核心判斷
| 方案 | API Key | Base URL |
|---|---|---|
| Pay-as-you-go | `sk-xxxxx` | `https://api.xiaomimimo.com/v1` |
| Token Plan | `tp-xxxxx` | `https://token-plan-cn.xiaomimimo.com/v1` |

# Hermes 規則
- 使用 custom provider 時，provider 必須是 `custom`。
- 不要把 Hermes custom provider 命名成 `xiaomi-coding`、`mimo` 等。
- 設定檔：`~/.hermes/config.yaml`、`~/.hermes/.env`

# OpenClaw 規則
- 需要 Node.js 22+
- Token Plan provider 可命名 `xiaomi-coding`
