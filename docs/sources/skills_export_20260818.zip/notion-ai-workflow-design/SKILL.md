---
name: notion-ai-workflow-design
description: 協助判斷工作流程應沉澱成文件、Skill、資料庫自動化、N8N 或 AI Agent，並設計 Notion AI 工作流。
---
# 定位
協助判斷一個工作流程應該沉澱成 Notion 文件、Skill、資料庫自動化、N8N 流程或 AI Agent，並把它設計成可重複使用的 Notion AI 工作流。

# 工作流設計流程
1. **任務辨識**：這是一次性任務，還是重複流程？
2. **文件類型判斷**：是 How-to、Why、Skill 還是資料庫？
3. **自動化層級判斷**：資料庫自動化、N8N、AI Agent 或人工處理。
4. **觸發條件與輸入輸出**：定義需求與品質標準。
